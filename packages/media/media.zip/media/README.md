# `@tadolingual/media`

> TODO: description

## Usage

```
const media = require('@tadolingual/media');

// TODO: DEMONSTRATE API
```
