class Article {
    constructor(title, content, author) {
      this.title = title;
      this.content = content;
      this.author = author;
    }
  }
  
  module.exports = Article;