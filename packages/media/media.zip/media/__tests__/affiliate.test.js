const AffiliateLink = require('../src/affiliate');

test('AffiliateLink exists', () => {
  expect(new AffiliateLink()).toBeDefined();
});
